<?php
class Member extends Model {
	
}
